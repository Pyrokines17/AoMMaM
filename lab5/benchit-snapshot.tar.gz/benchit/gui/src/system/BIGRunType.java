package system;

public enum BIGRunType {
	Compile, Run, Both;
}
