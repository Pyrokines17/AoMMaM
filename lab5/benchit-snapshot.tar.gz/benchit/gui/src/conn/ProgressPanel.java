package conn;

import javax.swing.JPanel;

/**
 * <p>
 * Überschrift: BenchIT
 * </p>
 * <p>
 * Beschreibung: This is highly DEPRECATED!!!
 * </p>
 * <p>
 * Copyright: Copyright (c) 2004
 * </p>
 * <p>
 * Organisation: ZHR TU Dresden
 * </p>
 * 
 * @author Robert Schoene
 * @version 1.0
 */
public class ProgressPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
