package conn;

/**
 * <p>
 * Überschrift: BenchIT
 * </p>
 * <p>
 * Beschreibung: The List of functions positioned in the upper left corner
 * </p>
 * <p>
 * Copyright: Copyright (c) 2004
 * </p>
 * <p>
 * Organisation: ZHR TU Dresden
 * </p>
 * 
 * @author Robert Schoene
 * @version 1.0
 */
public class FunctionList {
	/**
	 * a Vector containing the actual displayed graphs... should be deprectaed sometime... like this whole class
	 */
	// GraphData graphData ;
	/**
	 * Constructor
	 */
	public FunctionList() {
		super();

	}

}
