package gui;

public enum GUIState {
	LOADING, ADMIN, DATABASE, LOCALDEFS, KERNELS, RESULTS;
}