package gui;

public enum DetailLevel {
	Low, Medium, High;
}