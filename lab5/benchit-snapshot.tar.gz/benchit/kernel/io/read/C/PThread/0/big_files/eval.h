/********************************************************************
 * BenchIT - Performance Measurement for Scientific Applications
 * Contact: developer@benchit.org
 *
 * $Id: eval.h 1 2009-09-11 12:26:19Z william $
 * $URL: svn+ssh://william@rupert.zih.tu-dresden.de/svn-base/benchit-root/BenchITv6/kernel/io/read/C/PThread/0/big_files/eval.h $
 * For license details see COPYING in the package base directory
 *******************************************************************/

#ifndef eval_h
#define eval_h
void evaluate_environment(iods * pmydata);
#endif


