#####################################################################
# BenchIT - Performance Measurement for Scientific Applications
# Contact: developer@benchit.org
#
# $Id: README.txt 1 2009-09-11 12:26:19Z william $
# $URL: svn+ssh://william@rupert.zih.tu-dresden.de/svn-base/benchit-root/BenchITv6/kernel/io/mix/C/0/0/iozone_3d/README.txt $
#####################################################################

place the source files of ioprof in src directory or remove it and 
set a symlink pointing to this location.

rm -r src
ln -s /path/to/iozone /path/to/src
